from flask import Flask, jsonify


app = Flask(__name__,)




weathers = [
    #name1:   
        { 'name': 'Warszawa', 'temp': 15, 'speed': 24.7, 'hpa': 1026, 'deg': 20, 'humidity': 42, 'icon': "01d" },
    #name2:   
        { 'name': "Wroclaw",  'temp': 20, 'speed': 30.7, 'hpa': 1000, 'deg': 29, 'humidity': 42, 'icon': "01d"},
    #name3:   
        { 'name': "Kielce",  'temp': 21, 'speed': 11.0, 'hpa': 998, 'deg': 55, 'humidity': 2,'icon': "02d"},
    #name4:   
        { 'name': "Szczecin", 'temp': 15, 'speed': 5.4, 'hpa': 1022,'deg': 61, 'humidity': 20, 'icon': "03d"},
    #name4:   
        { 'name': "Gdańsk", 'temp': 12, 'speed': 33.1, 'hpa': 1020,'deg': 32, 'humidity': 40, 'icon': "02d"},
    #name5:   
        { 'name': "Białystok", 'temp': 10, 'speed': 1.2, 'hpa': 968,'deg': 61, 'humidity': 20, 'icon': "09d"},
    #name6:   
        { 'name': "Jelenia Góra", 'temp': 17, 'speed': 14.6, 'hpa': 998,'deg': 80, 'humidity': 11, 'icon': "01d"},
    #name7:   
        { 'name': "Legnica", 'temp': 15, 'speed': 12.6, 'hpa': 1010,'deg': 20, 'humidity': 5, 'icon': "03d"},
    #name8:   
        { 'name': "Rzeszów", 'temp': 7, 'speed': 70, 'hpa': 960,'deg': 88, 'humidity': 68, 'icon': "09d"},
    #name9:   
        { 'name': "Zakopane", 'temp': 1, 'speed': 5, 'hpa': 1022,'deg': 61, 'humidity': 20, 'icon': "03d"},

  

]

@app.route("/weathers", methods=["GET"])
def getWeathers():
	return jsonify(weathers)

@app.route("/weather/<id>", methods=["GET"])
def getWeather(id):
	id=int(id) -1
	return jsonify(weathers[id])



if __name__ == '__main__':
    app.run(debug=True)

